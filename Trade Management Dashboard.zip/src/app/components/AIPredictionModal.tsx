import { X, Brain, TrendingUp, AlertTriangle, Shield, Zap } from "lucide-react";

interface AIPredictionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AIPredictionModal({ isOpen, onClose }: AIPredictionModalProps) {
  if (!isOpen) return null;

  const recommendations = {
    lowRisk: [
      { name: "Johnson & Johnson", symbol: "JNJ", category: "Healthcare", expectedReturn: "4-6%", confidence: 92, price: 158.30 },
      { name: "Procter & Gamble", symbol: "PG", category: "Consumer Goods", expectedReturn: "3-5%", confidence: 89, price: 152.80 },
      { name: "Vanguard Total Bond", symbol: "BND", category: "Finance", expectedReturn: "3-4%", confidence: 95, price: 75.40 },
    ],
    mediumRisk: [
      { name: "Apple Inc.", symbol: "AAPL", category: "Technology", expectedReturn: "12-18%", confidence: 85, price: 185.50 },
      { name: "Pfizer Inc.", symbol: "PFE", category: "Healthcare", expectedReturn: "10-15%", confidence: 78, price: 28.90 },
      { name: "JPMorgan Chase", symbol: "JPM", category: "Finance", expectedReturn: "8-12%", confidence: 82, price: 174.20 },
      { name: "Ethereum", symbol: "ETH", category: "Crypto", expectedReturn: "15-25%", confidence: 71, price: 2400.00 },
    ],
    highRisk: [
      { name: "NVIDIA Corp.", symbol: "NVDA", category: "Technology", expectedReturn: "25-45%", confidence: 68, price: 495.20 },
      { name: "Tesla Inc.", symbol: "TSLA", category: "Technology", expectedReturn: "20-40%", confidence: 65, price: 255.00 },
      { name: "Moderna Inc.", symbol: "MRNA", category: "Medicine", expectedReturn: "30-50%", confidence: 62, price: 87.50 },
      { name: "Solana", symbol: "SOL", category: "Crypto", expectedReturn: "35-60%", confidence: 58, price: 98.50 },
      { name: "Quantum Computing", symbol: "QCI", category: "Research", expectedReturn: "40-80%", confidence: 54, price: 12.30 },
    ],
  };

  const categories = [
    { name: "Technology", count: 145, trend: "+12.3%" },
    { name: "Healthcare", count: 89, trend: "+8.7%" },
    { name: "Finance", count: 67, trend: "+5.4%" },
    { name: "Medicine", count: 54, trend: "+15.2%" },
    { name: "Research", count: 32, trend: "+22.8%" },
    { name: "Consumer Goods", count: 78, trend: "+4.1%" },
    { name: "Energy", count: 45, trend: "+7.9%" },
    { name: "Crypto", count: 234, trend: "+18.5%" },
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-7xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-gradient-to-r from-gray-900 to-gray-800 p-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-red-600 rounded-lg">
              <Brain className="h-6 w-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">AI Investment Predictor</h2>
              <p className="text-gray-300 mt-1">Data-driven recommendations based on market analysis</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
          >
            <X className="h-6 w-6 text-white" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="bg-gray-900 rounded-lg p-6 text-white">
            <h3 className="font-bold mb-4 flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-red-500" />
              Investment Categories Overview
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {categories.map((category, index) => (
                <div key={index} className="bg-gray-800 rounded-lg p-4 border border-gray-700 hover:border-red-500 transition-colors">
                  <p className="text-gray-300 text-sm">{category.name}</p>
                  <p className="text-xl font-bold mt-1">{category.count}</p>
                  <p className="text-green-400 text-sm mt-1">{category.trend}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-6">
            <div className="border-2 border-green-500 rounded-xl overflow-hidden">
              <div className="bg-green-50 p-4 flex items-center gap-3">
                <Shield className="h-6 w-6 text-green-600" />
                <div>
                  <h3 className="font-bold text-gray-900">Low Risk, Low Reward</h3>
                  <p className="text-sm text-gray-600">Stable investments with consistent returns (3-6% annually)</p>
                </div>
              </div>
              <div className="p-4 bg-white">
                <div className="grid gap-3">
                  {recommendations.lowRisk.map((rec, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:border-green-500 transition-colors">
                      <div className="flex-1">
                        <div className="flex items-center gap-3">
                          <div>
                            <p className="font-bold text-gray-900">{rec.name}</p>
                            <div className="flex items-center gap-2 mt-1">
                              <span className="text-sm text-gray-500">{rec.symbol}</span>
                              <span className="px-2 py-0.5 bg-gray-100 text-gray-700 rounded text-xs">{rec.category}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-gray-900">${rec.price}</p>
                        <p className="text-sm text-green-600">{rec.expectedReturn}</p>
                        <p className="text-xs text-gray-500">AI Confidence: {rec.confidence}%</p>
                      </div>
                      <button className="ml-4 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors">
                        Invest
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="border-2 border-yellow-500 rounded-xl overflow-hidden">
              <div className="bg-yellow-50 p-4 flex items-center gap-3">
                <TrendingUp className="h-6 w-6 text-yellow-600" />
                <div>
                  <h3 className="font-bold text-gray-900">Medium Risk, Medium Reward</h3>
                  <p className="text-sm text-gray-600">Balanced growth potential (8-25% annually)</p>
                </div>
              </div>
              <div className="p-4 bg-white">
                <div className="grid gap-3">
                  {recommendations.mediumRisk.map((rec, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:border-yellow-500 transition-colors">
                      <div className="flex-1">
                        <div className="flex items-center gap-3">
                          <div>
                            <p className="font-bold text-gray-900">{rec.name}</p>
                            <div className="flex items-center gap-2 mt-1">
                              <span className="text-sm text-gray-500">{rec.symbol}</span>
                              <span className="px-2 py-0.5 bg-gray-100 text-gray-700 rounded text-xs">{rec.category}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-gray-900">${rec.price}</p>
                        <p className="text-sm text-yellow-600">{rec.expectedReturn}</p>
                        <p className="text-xs text-gray-500">AI Confidence: {rec.confidence}%</p>
                      </div>
                      <button className="ml-4 px-4 py-2 bg-yellow-600 hover:bg-yellow-700 text-white rounded-lg transition-colors">
                        Invest
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="border-2 border-red-500 rounded-xl overflow-hidden">
              <div className="bg-red-50 p-4 flex items-center gap-3">
                <Zap className="h-6 w-6 text-red-600" />
                <div>
                  <h3 className="font-bold text-gray-900">High Risk, High Reward</h3>
                  <p className="text-sm text-gray-600">Aggressive growth opportunities (25-80% annually)</p>
                </div>
              </div>
              <div className="p-4 bg-white">
                <div className="grid gap-3">
                  {recommendations.highRisk.map((rec, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:border-red-500 transition-colors">
                      <div className="flex-1">
                        <div className="flex items-center gap-3">
                          <AlertTriangle className="h-5 w-5 text-red-500" />
                          <div>
                            <p className="font-bold text-gray-900">{rec.name}</p>
                            <div className="flex items-center gap-2 mt-1">
                              <span className="text-sm text-gray-500">{rec.symbol}</span>
                              <span className="px-2 py-0.5 bg-gray-100 text-gray-700 rounded text-xs">{rec.category}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-gray-900">${rec.price}</p>
                        <p className="text-sm text-red-600">{rec.expectedReturn}</p>
                        <p className="text-xs text-gray-500">AI Confidence: {rec.confidence}%</p>
                      </div>
                      <button className="ml-4 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors">
                        Invest
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="bg-gray-900 rounded-lg p-6 text-white">
            <div className="flex items-start gap-3">
              <AlertTriangle className="h-6 w-6 text-red-500 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-bold mb-2">Investment Disclaimer</h3>
                <p className="text-gray-300 text-sm">
                  AI predictions are based on historical data and market trends. Past performance does not guarantee future results. 
                  Always conduct your own research and consider consulting with a financial advisor before making investment decisions. 
                  Cryptocurrency and stock investments carry inherent risks.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
