import { X, AlertTriangle, User, DollarSign } from "lucide-react";
import { useState } from "react";

interface WithdrawalModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function WithdrawalModal({ isOpen, onClose }: WithdrawalModalProps) {
  const [amount, setAmount] = useState("");
  const [calculatedFee, setCalculatedFee] = useState(0);
  const [netAmount, setNetAmount] = useState(0);

  if (!isOpen) return null;

  const handleAmountChange = (value: string) => {
    setAmount(value);
    const numValue = parseFloat(value) || 0;
    const fee = numValue * 0.01; // 1% fee
    setCalculatedFee(fee);
    setNetAmount(numValue - fee);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-lg w-full">
        <div className="bg-gradient-to-r from-gray-900 to-gray-800 p-6 flex items-center justify-between rounded-t-xl">
          <div>
            <h2 className="text-2xl font-bold text-white">Withdraw Earnings</h2>
            <p className="text-gray-300 mt-1">Retire your funds to your bank account</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
          >
            <X className="h-6 w-6 text-white" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-gray-900 mb-1">Co-Owner Fee Notice</h3>
                <p className="text-sm text-gray-700">
                  1% of all withdrawals are automatically transferred to the platform co-owner, 
                  <span className="font-semibold"> annonymatus</span>, as per the platform agreement.
                </p>
              </div>
            </div>
          </div>

          <div>
            <label className="block font-medium text-gray-900 mb-2">
              Withdrawal Amount (USD)
            </label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="number"
                value={amount}
                onChange={(e) => handleAmountChange(e.target.value)}
                placeholder="0.00"
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-600 focus:border-transparent"
              />
            </div>
          </div>

          {amount && parseFloat(amount) > 0 && (
            <div className="bg-gray-50 rounded-lg p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Requested Amount:</span>
                <span className="font-semibold text-gray-900">${parseFloat(amount).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
              <div className="border-t border-gray-200 pt-3">
                <div className="flex items-center justify-between text-sm mb-2">
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4 text-red-600" />
                    <span className="text-gray-600">Co-Owner Fee (anonnymatus):</span>
                  </div>
                  <span className="font-medium text-red-600">-${calculatedFee.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                </div>
              </div>
              <div className="border-t border-gray-200 pt-3">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-gray-900">You Receive:</span>
                  <span className="font-bold text-green-600">${netAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                </div>
              </div>
            </div>
          )}

          <div className="bg-gray-900 rounded-lg p-4 text-white text-sm">
            <p className="mb-2"><strong>Important:</strong> Withdrawal processing times:</p>
            <ul className="list-disc list-inside space-y-1 text-gray-300 ml-2">
              <li>Standard: 2-3 business days</li>
              <li>Express: 24 hours (additional 2% fee)</li>
            </ul>
          </div>

          <div className="flex gap-3">
            <button
              onClick={onClose}
              className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
            >
              Cancel
            </button>
            <button
              disabled={!amount || parseFloat(amount) <= 0}
              className="flex-1 px-4 py-3 bg-red-600 hover:bg-red-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white rounded-lg transition-colors font-medium"
            >
              Confirm Withdrawal
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
