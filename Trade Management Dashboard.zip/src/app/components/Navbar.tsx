import { Wallet, TrendingUp, Bitcoin, BarChart3, HelpCircle, Brain } from "lucide-react";

interface NavbarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  onHelpClick: () => void;
  onAIClick: () => void;
}

export function Navbar({ activeTab, onTabChange, onHelpClick, onAIClick }: NavbarProps) {
  const tabs = [
    { id: "wallet", label: "Wallet", icon: Wallet },
    { id: "trading", label: "Trading", icon: TrendingUp },
    { id: "crypto", label: "Crypto", icon: Bitcoin },
    { id: "stocks", label: "Stocks", icon: BarChart3 },
  ];

  return (
    <nav className="border-b bg-gray-900 border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-8 w-8 text-red-600" />
              <div>
                <h1 className="text-xl font-semibold text-white tracking-tight">beetleguse</h1>
                <p className="text-xs text-gray-400 -mt-0.5">Trades in one place</p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onAIClick}
              className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors font-medium"
            >
              <Brain className="h-5 w-5" />
              <span className="hidden sm:inline">AI Predictor</span>
            </button>
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => onTabChange(tab.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors font-medium ${
                    activeTab === tab.id
                      ? "bg-red-600 text-white"
                      : "text-gray-300 hover:bg-gray-800"
                  }`}
                >
                  <Icon className="h-5 w-5" />
                  <span className="hidden sm:inline">{tab.label}</span>
                </button>
              );
            })}
            <button
              onClick={onHelpClick}
              className="flex items-center gap-2 px-4 py-2 text-gray-300 hover:bg-gray-800 rounded-lg transition-colors font-medium"
            >
              <HelpCircle className="h-5 w-5" />
              <span className="hidden sm:inline">Help</span>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}