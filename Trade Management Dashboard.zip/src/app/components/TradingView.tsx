import { useState } from "react";
import { TrendingUp, TrendingDown, Clock, CheckCircle, XCircle, HelpCircle } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

interface TradingViewProps {
  onHelpClick: () => void;
}

export function TradingView({ onHelpClick }: TradingViewProps) {
  const [orderType, setOrderType] = useState<"buy" | "sell">("buy");
  const [selectedAsset, setSelectedAsset] = useState("BTC");

  const chartData = [
    { time: "09:00", price: 44200 },
    { time: "10:00", price: 44350 },
    { time: "11:00", price: 44100 },
    { time: "12:00", price: 44500 },
    { time: "13:00", price: 44650 },
    { time: "14:00", price: 44300 },
    { time: "15:00", price: 44450 },
  ];

  const recentTrades = [
    { id: 1, asset: "BTC", type: "buy", amount: 0.5, price: 44300, status: "completed", time: "2 mins ago" },
    { id: 2, asset: "ETH", type: "sell", amount: 1.2, price: 2400, status: "completed", time: "15 mins ago" },
    { id: 3, asset: "AAPL", type: "buy", amount: 10, price: 185, status: "pending", time: "1 hour ago" },
    { id: 4, asset: "TSLA", type: "sell", amount: 5, price: 255, status: "failed", time: "2 hours ago" },
  ];

  const analysis = {
    buySignals: 3,
    sellSignals: 1,
    recommendation: "Buy",
    confidence: 78,
    indicators: [
      { name: "RSI", value: 65, signal: "Neutral" },
      { name: "MACD", value: "Bullish", signal: "Buy" },
      { name: "Moving Avg", value: "Above", signal: "Buy" },
      { name: "Volume", value: "High", signal: "Buy" },
    ]
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 space-y-6">
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-900">{selectedAsset}/USD</h2>
            <div className="flex gap-2">
              <select
                value={selectedAsset}
                onChange={(e) => setSelectedAsset(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg text-gray-900 bg-white"
              >
                <option value="BTC">Bitcoin (BTC)</option>
                <option value="ETH">Ethereum (ETH)</option>
                <option value="AAPL">Apple (AAPL)</option>
                <option value="TSLA">Tesla (TSLA)</option>
              </select>
            </div>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="price" stroke="#dc2626" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200">
          <div className="p-6 border-b">
            <h2 className="text-xl font-bold text-gray-900">Recent Trades</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Asset</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Time</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {recentTrades.map((trade) => (
                  <tr key={trade.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap font-medium text-gray-900">{trade.asset}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 rounded text-xs ${trade.type === 'buy' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                        {trade.type.toUpperCase()}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-gray-900">{trade.amount}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-gray-900">${trade.price.toLocaleString()}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center gap-1">
                        {trade.status === 'completed' && <CheckCircle className="h-4 w-4 text-green-600" />}
                        {trade.status === 'pending' && <Clock className="h-4 w-4 text-yellow-600" />}
                        {trade.status === 'failed' && <XCircle className="h-4 w-4 text-red-600" />}
                        <span className="text-sm text-gray-600 capitalize">{trade.status}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{trade.time}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Trade Analysis</h2>
          <div className={`p-4 rounded-lg mb-4 ${analysis.recommendation === 'Buy' ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'}`}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-600">Recommendation</span>
              <span className={`font-bold ${analysis.recommendation === 'Buy' ? 'text-green-600' : 'text-red-600'}`}>
                {analysis.recommendation}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Confidence</span>
              <span className="font-bold text-gray-900">{analysis.confidence}%</span>
            </div>
          </div>
          <div className="space-y-3">
            <h3 className="font-medium text-gray-900">Indicators</h3>
            {analysis.indicators.map((indicator, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">{indicator.name}</p>
                  <p className="text-sm text-gray-600">{indicator.value}</p>
                </div>
                <span className={`px-2 py-1 rounded text-xs ${
                  indicator.signal === 'Buy' ? 'bg-green-100 text-green-800' : 
                  indicator.signal === 'Sell' ? 'bg-red-100 text-red-800' : 
                  'bg-gray-100 text-gray-800'
                }`}>
                  {indicator.signal}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-900">Quick Trade</h2>
            <button
              onClick={onHelpClick}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              title="Need help with trading?"
            >
              <HelpCircle className="h-5 w-5 text-gray-600" />
            </button>
          </div>
          <div className="flex gap-2 mb-4">
            <button
              onClick={() => setOrderType("buy")}
              className={`flex-1 py-2 rounded-lg transition-colors ${
                orderType === "buy"
                  ? "bg-green-600 text-white"
                  : "bg-gray-100 text-gray-600"
              }`}
            >
              Buy
            </button>
            <button
              onClick={() => setOrderType("sell")}
              className={`flex-1 py-2 rounded-lg transition-colors ${
                orderType === "sell"
                  ? "bg-red-600 text-white"
                  : "bg-gray-100 text-gray-600"
              }`}
            >
              Sell
            </button>
          </div>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Amount</label>
              <input
                type="number"
                placeholder="0.00"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Price (USD)</label>
              <input
                type="number"
                placeholder="44,300"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
              />
            </div>
            <button
              className={`w-full py-3 rounded-lg text-white font-medium ${
                orderType === "buy" ? "bg-green-600 hover:bg-green-700" : "bg-red-600 hover:bg-red-700"
              }`}
            >
              {orderType === "buy" ? "Place Buy Order" : "Place Sell Order"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}