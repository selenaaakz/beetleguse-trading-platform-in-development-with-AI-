import { TrendingUp, TrendingDown, Star } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";

export function StocksView() {
  const stockData = [
    { name: "Apple Inc.", symbol: "AAPL", price: 185.50, change: 2.15, volume: "52.3M", pe: 29.8, sector: "Technology", category: "Technology" },
    { name: "Tesla Inc.", symbol: "TSLA", price: 255.00, change: -1.45, volume: "98.5M", pe: 65.2, sector: "Technology", category: "Technology" },
    { name: "Microsoft Corp.", symbol: "MSFT", price: 378.90, change: 1.23, volume: "31.2M", pe: 35.4, sector: "Technology", category: "Technology" },
    { name: "Amazon.com Inc.", symbol: "AMZN", price: 152.30, change: 3.67, volume: "45.8M", pe: 42.1, sector: "E-commerce", category: "Technology" },
    { name: "NVIDIA Corp.", symbol: "NVDA", price: 495.20, change: 4.23, volume: "67.4M", pe: 78.5, sector: "Technology", category: "Technology" },
    { name: "Pfizer Inc.", symbol: "PFE", price: 28.90, change: 2.34, volume: "34.5M", pe: 18.2, sector: "Healthcare", category: "Medicine" },
    { name: "Johnson & Johnson", symbol: "JNJ", price: 158.30, change: 0.89, volume: "12.8M", pe: 24.1, sector: "Healthcare", category: "Medicine" },
  ];

  const sectorData = [
    { name: "Technology", value: 45, color: "#dc2626" },
    { name: "Healthcare", value: 20, color: "#16a34a" },
    { name: "Finance", value: 15, color: "#1f2937" },
    { name: "Consumer", value: 12, color: "#6b7280" },
    { name: "Energy", value: 8, color: "#ef4444" },
  ];

  const performanceData = [
    { period: "1W", performance: 2.5 },
    { period: "1M", performance: 5.8 },
    { period: "3M", performance: -1.2 },
    { period: "6M", performance: 8.9 },
    { period: "1Y", performance: 15.3 },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h3 className="font-bold text-gray-900 mb-4">Portfolio by Sector</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={sectorData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name} ${value}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {sectorData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h3 className="font-bold text-gray-900 mb-4">Portfolio Performance</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="period" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="performance" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-900">Stock Markets</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Company</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Change</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Volume</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">P/E Ratio</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sector</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {stockData.map((stock, index) => (
                <tr key={index} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-2">
                      <Star className="h-4 w-4 text-gray-400 hover:text-yellow-400 cursor-pointer" />
                      <div>
                        <div className="font-medium text-gray-900">{stock.name}</div>
                        <div className="text-sm text-gray-500">{stock.symbol}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs">
                      {stock.category}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap font-medium text-gray-900">
                    ${stock.price.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`flex items-center gap-1 ${stock.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {stock.change >= 0 ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
                      {stock.change >= 0 ? '+' : ''}{stock.change}%
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-900">{stock.volume}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-900">{stock.pe}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 py-1 bg-red-100 text-red-800 rounded text-xs">
                      {stock.sector}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <button className="px-3 py-1 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
                      Trade
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl p-6 text-white">
          <p className="text-green-100 mb-2">Portfolio Value</p>
          <p className="text-3xl font-bold">$87,450</p>
          <div className="flex items-center gap-1 mt-2">
            <TrendingUp className="h-4 w-4" />
            <span>+12.5% This Month</span>
          </div>
        </div>

        <div className="bg-gradient-to-br from-red-600 to-red-700 rounded-xl p-6 text-white">
          <p className="text-red-100 mb-2">Total Return</p>
          <p className="text-3xl font-bold">+15.3%</p>
          <div className="flex items-center gap-1 mt-2">
            <TrendingUp className="h-4 w-4" />
            <span>This Year</span>
          </div>
        </div>

        <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl p-6 text-white">
          <p className="text-gray-100 mb-2">Active Positions</p>
          <p className="text-3xl font-bold">12</p>
          <div className="mt-2">
            <span>Across 5 Sectors</span>
          </div>
        </div>
      </div>
    </div>
  );
}