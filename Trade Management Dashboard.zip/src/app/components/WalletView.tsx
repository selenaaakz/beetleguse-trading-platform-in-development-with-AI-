import { Wallet, TrendingUp, TrendingDown, DollarSign, Info, ArrowDownToLine } from "lucide-react";

interface WalletViewProps {
  onWithdrawClick: () => void;
}

export function WalletView({ onWithdrawClick }: WalletViewProps) {
  const walletData = {
    totalBalance: 125430.50,
    available: 85430.50,
    inTrades: 40000.00,
    todayChange: 2.34,
    todayChangeAmount: 2870.45,
  };

  const assets = [
    { name: "Bitcoin", symbol: "BTC", amount: 0.5, value: 22150.00, change: 3.2, category: "Crypto" },
    { name: "Ethereum", symbol: "ETH", amount: 3.2, value: 7680.00, change: -1.5, category: "Crypto" },
    { name: "Apple Inc.", symbol: "AAPL", shares: 25, value: 4625.00, change: 1.8, category: "Technology" },
    { name: "Tesla Inc.", symbol: "TSLA", shares: 15, value: 3825.00, change: -2.1, category: "Technology" },
    { name: "USD Cash", symbol: "USD", amount: 87150.50, value: 87150.50, change: 0, category: "Finance" },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-red-600 to-red-700 rounded-xl p-6 text-white relative">
          <div className="flex items-center gap-2 mb-2">
            <Wallet className="h-5 w-5" />
            <p className="text-red-100 font-light">Total Balance</p>
          </div>
          <p className="text-3xl font-semibold">${walletData.totalBalance.toLocaleString()}</p>
          <div className={`flex items-center gap-1 mt-2 ${walletData.todayChange >= 0 ? 'text-green-200' : 'text-red-200'}`}>
            {walletData.todayChange >= 0 ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
            <span className="font-light">{walletData.todayChange >= 0 ? '+' : ''}{walletData.todayChange}% (${walletData.todayChangeAmount.toLocaleString()})</span>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center gap-2 mb-2">
            <DollarSign className="h-5 w-5 text-green-600" />
            <p className="text-gray-600 font-light">Available</p>
          </div>
          <p className="text-3xl font-semibold text-gray-900">${walletData.available.toLocaleString()}</p>
          <p className="text-sm text-gray-500 mt-2 font-light">Ready to trade</p>
        </div>

        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="h-5 w-5 text-red-600" />
            <p className="text-gray-600 font-light">In Trades</p>
          </div>
          <p className="text-3xl font-semibold text-gray-900">${walletData.inTrades.toLocaleString()}</p>
          <p className="text-sm text-gray-500 mt-2 font-light">Active positions</p>
        </div>

        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="h-5 w-5 text-purple-600" />
            <p className="text-gray-600 font-light">Assets</p>
          </div>
          <p className="text-3xl font-semibold text-gray-900">{assets.length}</p>
          <p className="text-sm text-gray-500 mt-2 font-light">Different holdings</p>
        </div>
      </div>

      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <Info className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <h3 className="font-semibold text-gray-900 mb-1">Co-Ownership Notice</h3>
            <p className="text-sm text-gray-700">
              This platform is co-owned by <span className="font-semibold">annonymatus</span>. 
              All withdrawal transactions include a 1% automatic transfer to the co-owner as per platform agreement.
            </p>
          </div>
          <button
            onClick={onWithdrawClick}
            className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors font-medium whitespace-nowrap"
          >
            <ArrowDownToLine className="h-4 w-4" />
            Withdraw
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">Your Assets</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Asset</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Value</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">24h Change</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {assets.map((asset, index) => (
                <tr key={index} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="font-medium text-gray-900">{asset.name}</div>
                      <div className="text-sm text-gray-500 font-light">{asset.symbol}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs font-medium">
                      {asset.category}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-900 font-light">
                    {asset.amount || asset.shares} {asset.shares ? 'shares' : asset.symbol}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-900 font-medium">
                    ${asset.value.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`flex items-center gap-1 font-medium ${asset.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {asset.change >= 0 ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
                      {asset.change >= 0 ? '+' : ''}{asset.change}%
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}