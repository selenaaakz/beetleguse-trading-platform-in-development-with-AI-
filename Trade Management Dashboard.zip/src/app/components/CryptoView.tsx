import { TrendingUp, TrendingDown, Star } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

export function CryptoView() {
  const cryptoData = [
    { name: "Bitcoin", symbol: "BTC", price: 44300, change: 3.45, volume: "28.5B", marketCap: "865B", sparkline: generateSparkline(44300), category: "Crypto" },
    { name: "Ethereum", symbol: "ETH", price: 2400, change: -1.23, volume: "15.2B", marketCap: "288B", sparkline: generateSparkline(2400), category: "Crypto" },
    { name: "Binance Coin", symbol: "BNB", price: 315, change: 2.15, volume: "1.8B", marketCap: "48.5B", sparkline: generateSparkline(315), category: "Crypto" },
    { name: "Cardano", symbol: "ADA", price: 0.58, change: 5.67, volume: "890M", marketCap: "20.4B", sparkline: generateSparkline(0.58), category: "Crypto" },
    { name: "Solana", symbol: "SOL", price: 98.50, change: -2.34, volume: "2.1B", marketCap: "42.1B", sparkline: generateSparkline(98.50), category: "Crypto" },
    { name: "Ripple", symbol: "XRP", price: 0.62, change: 1.89, volume: "1.5B", marketCap: "33.2B", sparkline: generateSparkline(0.62), category: "Crypto" },
  ];

  const topGainers = [
    { symbol: "ADA", change: 5.67 },
    { symbol: "BTC", change: 3.45 },
    { symbol: "BNB", change: 2.15 },
  ];

  const topLosers = [
    { symbol: "SOL", change: -2.34 },
    { symbol: "ETH", change: -1.23 },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="h-5 w-5 text-green-600" />
            <h3 className="font-bold text-gray-900">Top Gainers (24h)</h3>
          </div>
          <div className="space-y-3">
            {topGainers.map((crypto, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                <span className="font-medium text-gray-900">{crypto.symbol}</span>
                <span className="text-green-600 font-bold">+{crypto.change}%</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center gap-2 mb-4">
            <TrendingDown className="h-5 w-5 text-red-600" />
            <h3 className="font-bold text-gray-900">Top Losers (24h)</h3>
          </div>
          <div className="space-y-3">
            {topLosers.map((crypto, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                <span className="font-medium text-gray-900">{crypto.symbol}</span>
                <span className="text-red-600 font-bold">{crypto.change}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200">
        <div className="p-6 border-b">
          <h2 className="text-xl font-bold text-gray-900">Cryptocurrency Markets</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">24h Change</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Volume</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Market Cap</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Last 7 Days</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {cryptoData.map((crypto, index) => (
                <tr key={index} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-2">
                      <Star className="h-4 w-4 text-gray-400 hover:text-yellow-400 cursor-pointer" />
                      <div>
                        <div className="font-medium text-gray-900">{crypto.name}</div>
                        <div className="text-sm text-gray-500">{crypto.symbol}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs">
                      {crypto.category}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap font-medium text-gray-900">
                    ${crypto.price.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`flex items-center gap-1 ${crypto.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {crypto.change >= 0 ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
                      {crypto.change >= 0 ? '+' : ''}{crypto.change}%
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-900">${crypto.volume}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-900">${crypto.marketCap}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="w-24 h-8">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={crypto.sparkline}>
                          <Area 
                            type="monotone" 
                            dataKey="value" 
                            stroke={crypto.change >= 0 ? "#16a34a" : "#dc2626"} 
                            fill={crypto.change >= 0 ? "#bbf7d0" : "#fecaca"}
                            strokeWidth={2}
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <button className="px-3 py-1 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
                      Trade
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function generateSparkline(basePrice: number) {
  const data = [];
  let price = basePrice;
  for (let i = 0; i < 7; i++) {
    const change = (Math.random() - 0.5) * basePrice * 0.05;
    price += change;
    data.push({ value: price });
  }
  return data;
}