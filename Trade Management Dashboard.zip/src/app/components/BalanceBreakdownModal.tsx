import { X, TrendingUp, TrendingDown, Calendar } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts";

interface BalanceBreakdownModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function BalanceBreakdownModal({ isOpen, onClose }: BalanceBreakdownModalProps) {
  if (!isOpen) return null;

  const growthData = {
    day: { amount: 456.78, percentage: 0.36, chart: [
      { time: '00:00', value: 125000 },
      { time: '04:00', value: 125100 },
      { time: '08:00', value: 125200 },
      { time: '12:00', value: 125300 },
      { time: '16:00', value: 125350 },
      { time: '20:00', value: 125430 },
    ]},
    month: { amount: 8234.50, percentage: 7.02, chart: [
      { period: 'Week 1', value: 117200 },
      { period: 'Week 2', value: 119500 },
      { period: 'Week 3', value: 122800 },
      { period: 'Week 4', value: 125430 },
    ]},
    year: { amount: 23567.89, percentage: 23.13, chart: [
      { month: 'Jan', value: 101863 },
      { month: 'Feb', value: 105234 },
      { month: 'Mar', value: 108120 },
      { month: 'Apr', value: 110543 },
      { month: 'May', value: 112876 },
      { month: 'Jun', value: 115234 },
      { month: 'Jul', value: 117890 },
      { month: 'Aug', value: 119765 },
      { month: 'Sep', value: 121543 },
      { month: 'Oct', value: 123234 },
      { month: 'Nov', value: 124567 },
      { month: 'Dec', value: 125430 },
    ]},
    decade: { amount: 98750.30, percentage: 371.2, chart: [
      { year: '2015', value: 26630 },
      { year: '2016', value: 35421 },
      { year: '2017', value: 42589 },
      { year: '2018', value: 48234 },
      { year: '2019', value: 56789 },
      { year: '2020', value: 67234 },
      { year: '2021', value: 82345 },
      { year: '2022', value: 95678 },
      { year: '2023', value: 108234 },
      { year: '2024', value: 125430 },
    ]},
  };

  const periods = [
    { key: 'day', label: 'Today', icon: Calendar },
    { key: 'month', label: 'This Month', icon: Calendar },
    { key: 'year', label: 'This Year', icon: Calendar },
    { key: 'decade', label: '10 Years', icon: Calendar },
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-6xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b p-6 flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Balance Growth Breakdown</h2>
            <p className="text-gray-600 mt-1">Detailed analysis of your portfolio growth over time</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="h-6 w-6 text-gray-600" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {periods.map(({ key, label }) => {
            const data = growthData[key as keyof typeof growthData];
            const Icon = data.percentage >= 0 ? TrendingUp : TrendingDown;
            
            return (
              <div key={key} className="border border-gray-200 rounded-xl overflow-hidden">
                <div className="bg-gray-900 p-4 flex items-center justify-between">
                  <h3 className="font-bold text-white">{label}</h3>
                  <div className={`flex items-center gap-2 ${data.percentage >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    <Icon className="h-5 w-5" />
                    <span className="font-bold">
                      {data.percentage >= 0 ? '+' : ''}${data.amount.toLocaleString()} ({data.percentage >= 0 ? '+' : ''}{data.percentage}%)
                    </span>
                  </div>
                </div>
                <div className="p-4 bg-white">
                  <div className="h-48">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={data.chart}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey={Object.keys(data.chart[0])[0]} />
                        <YAxis />
                        <Tooltip formatter={(value) => `$${Number(value).toLocaleString()}`} />
                        <Line 
                          type="monotone" 
                          dataKey="value" 
                          stroke={data.percentage >= 0 ? "#22c55e" : "#ef4444"} 
                          strokeWidth={2}
                          dot={{ fill: data.percentage >= 0 ? "#22c55e" : "#ef4444" }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            );
          })}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-lg p-6 text-white">
              <p className="text-gray-300 mb-2">Average Daily Growth</p>
              <p className="text-3xl font-bold">$456</p>
              <p className="text-sm text-gray-400 mt-2">Based on 365-day average</p>
            </div>
            <div className="bg-gradient-to-br from-red-600 to-red-700 rounded-lg p-6 text-white">
              <p className="text-red-100 mb-2">Best Month</p>
              <p className="text-3xl font-bold">+$12,450</p>
              <p className="text-sm text-red-200 mt-2">September 2024</p>
            </div>
            <div className="bg-gradient-to-br from-gray-700 to-gray-800 rounded-lg p-6 text-white">
              <p className="text-gray-300 mb-2">Total ROI</p>
              <p className="text-3xl font-bold">+371%</p>
              <p className="text-sm text-gray-400 mt-2">Since inception</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
