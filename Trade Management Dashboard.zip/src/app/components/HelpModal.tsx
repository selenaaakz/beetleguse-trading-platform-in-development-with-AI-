import { X, HelpCircle, BookOpen, MessageCircle, Shield } from "lucide-react";

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function HelpModal({ isOpen, onClose }: HelpModalProps) {
  if (!isOpen) return null;

  const helpTopics = [
    {
      icon: BookOpen,
      title: "How to Execute a Trade",
      content: "Select an asset, choose buy or sell, enter the amount and price, then click 'Place Order'. Your order will be processed instantly."
    },
    {
      icon: Shield,
      title: "Understanding Risk Levels",
      content: "Low Risk: Stable returns, minimal volatility. Medium Risk: Balanced growth potential. High Risk: Maximum returns with higher volatility."
    },
    {
      icon: MessageCircle,
      title: "Reading Market Indicators",
      content: "RSI shows momentum, MACD indicates trends, Moving Average shows price direction, and Volume confirms market activity."
    },
    {
      icon: HelpCircle,
      title: "Portfolio Diversification",
      content: "Spread investments across different sectors (Technology, Healthcare, Finance) to minimize risk and maximize returns."
    }
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b p-6 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-gray-900">Help Center</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="h-6 w-6 text-gray-600" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {helpTopics.map((topic, index) => {
            const Icon = topic.icon;
            return (
              <div key={index} className="border border-gray-200 rounded-lg p-4 hover:border-red-500 transition-colors">
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-red-50 rounded-lg">
                    <Icon className="h-6 w-6 text-red-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-gray-900 mb-2">{topic.title}</h3>
                    <p className="text-gray-600">{topic.content}</p>
                  </div>
                </div>
              </div>
            );
          })}

          <div className="bg-gray-900 rounded-lg p-6 text-white">
            <h3 className="font-bold mb-2">Still Need Help?</h3>
            <p className="text-gray-300 mb-4">Our support team is available 24/7 to assist you with any questions.</p>
            <button className="px-4 py-2 bg-red-600 hover:bg-red-700 rounded-lg transition-colors">
              Contact Support
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
