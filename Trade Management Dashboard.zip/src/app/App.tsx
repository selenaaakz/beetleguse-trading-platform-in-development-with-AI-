import { useState } from "react";
import { Navbar } from "./components/Navbar";
import { WalletView } from "./components/WalletView";
import { TradingView } from "./components/TradingView";
import { CryptoView } from "./components/CryptoView";
import { StocksView } from "./components/StocksView";
import { HelpModal } from "./components/HelpModal";
import { BalanceBreakdownModal } from "./components/BalanceBreakdownModal";
import { AIPredictionModal } from "./components/AIPredictionModal";
import { WithdrawalModal } from "./components/WithdrawalModal";
import { Info } from "lucide-react";

export default function App() {
  const [activeTab, setActiveTab] = useState("wallet");
  const [isHelpModalOpen, setIsHelpModalOpen] = useState(false);
  const [isBalanceModalOpen, setIsBalanceModalOpen] = useState(false);
  const [isAIModalOpen, setIsAIModalOpen] = useState(false);
  const [isWithdrawalModalOpen, setIsWithdrawalModalOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar 
        activeTab={activeTab} 
        onTabChange={setActiveTab}
        onHelpClick={() => setIsHelpModalOpen(true)}
        onAIClick={() => setIsAIModalOpen(true)}
      />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === "wallet" && (
          <div className="space-y-6">
            <button
              onClick={() => setIsBalanceModalOpen(true)}
              className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors font-medium"
            >
              <Info className="h-5 w-5" />
              View Balance Breakdown
            </button>
            <WalletView onWithdrawClick={() => setIsWithdrawalModalOpen(true)} />
          </div>
        )}
        {activeTab === "trading" && <TradingView onHelpClick={() => setIsHelpModalOpen(true)} />}
        {activeTab === "crypto" && <CryptoView />}
        {activeTab === "stocks" && <StocksView />}
      </main>

      <HelpModal isOpen={isHelpModalOpen} onClose={() => setIsHelpModalOpen(false)} />
      <BalanceBreakdownModal isOpen={isBalanceModalOpen} onClose={() => setIsBalanceModalOpen(false)} />
      <AIPredictionModal isOpen={isAIModalOpen} onClose={() => setIsAIModalOpen(false)} />
      <WithdrawalModal isOpen={isWithdrawalModalOpen} onClose={() => setIsWithdrawalModalOpen(false)} />
    </div>
  );
}